import React, { useState } from "react";
import API from "../api";
export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const handleSubmit = async (e) => {
    e.preventDefault();
    await API.post("/users/register", { name, email, password });
    alert("Registered!");
  };
  return (<form onSubmit={handleSubmit}><input placeholder="Name" onChange={e=>setName(e.target.value)} /><input placeholder="Email" onChange={e=>setEmail(e.target.value)} /><input placeholder="Password" type="password" onChange={e=>setPassword(e.target.value)} /><button type="submit">Register</button></form>);
}