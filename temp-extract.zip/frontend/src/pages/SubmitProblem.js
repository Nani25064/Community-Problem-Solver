import React, { useState } from "react";
import API from "../api";
export default function SubmitProblem() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const handleSubmit = async (e) => {
    e.preventDefault();
    await API.post("/problems", { title, description });
    alert("Problem submitted!");
  };
  return (<form onSubmit={handleSubmit}><input placeholder="Title" onChange={e=>setTitle(e.target.value)} /><textarea placeholder="Description" onChange={e=>setDescription(e.target.value)} /><button type="submit">Submit</button></form>);
}