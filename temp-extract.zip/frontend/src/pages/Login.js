import React, { useState } from "react";
import API from "../api";
export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const handleSubmit = async (e) => {
    e.preventDefault();
    await API.post("/users/login", { email, password });
    alert("Logged in!");
  };
  return (<form onSubmit={handleSubmit}><input placeholder="Email" onChange={e=>setEmail(e.target.value)} /><input placeholder="Password" type="password" onChange={e=>setPassword(e.target.value)} /><button type="submit">Login</button></form>);
}