import React, { useEffect, useState } from "react";
import API from "../api";
export default function ProblemList() {
  const [problems, setProblems] = useState([]);
  useEffect(() => { API.get("/problems").then(res => setProblems(res.data)); }, []);
  return (<div>{problems.map(p => <div key={p._id}><h3>{p.title}</h3><p>{p.description}</p></div>)}</div>);
}